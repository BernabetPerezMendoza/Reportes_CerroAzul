<?php include 'views/layouts/header.php'; ?>

<div class="mb-8 flex justify-between items-center flex-wrap gap-4">
    <h2 class="text-2xl font-black text-slate-800">Panel de Control de la Municipalidad</h2>
    <a href="index.php?action=admin_usuarios" class="bg-blue-600 hover:bg-blue-700 text-white font-medium text-sm px-4 py-2 rounded-xl shadow transition"><i class="fa-solid fa-users-gear mr-2"></i>Gestionar Usuarios / Admins</a>
</div>

<div class="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8">
    <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
        <p class="text-sm font-medium text-slate-500">Reportes Generales</p>
        <p class="text-3xl font-black text-slate-800 mt-1"><?php echo $counts['total'] ?? 0; ?></p>
    </div>
    <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 border-l-4 border-l-amber-500">
        <p class="text-sm font-medium text-slate-500">Por Revisar</p>
        <p class="text-3xl font-black text-amber-600 mt-1"><?php echo $counts['pendientes'] ?? 0; ?></p>
    </div>
    <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 border-l-4 border-l-emerald-500">
        <p class="text-sm font-medium text-slate-500">Listos / Revisados</p>
        <p class="text-3xl font-black text-emerald-600 mt-1"><?php echo $counts['revisados'] ?? 0; ?></p>
    </div>
</div>

<div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
    <div class="px-6 py-4 border-b border-slate-100">
        <h3 class="font-bold text-slate-800 text-lg">Alertas Ciudadanas</h3>
    </div>
    <div class="overflow-x-auto">
        <table class="w-full text-left border-collapse">
            <thead>
                <tr class="bg-slate-50 text-slate-500 text-xs font-bold uppercase tracking-wider border-b border-slate-200">
                    <th class="px-6 py-3">Ciudadano</th>
                    <th class="px-6 py-3">Descripción</th>
                    <th class="px-6 py-3">Foto</th>
                    <th class="px-6 py-3">Estado</th>
                    <th class="px-6 py-3 text-right">Acción</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-100 text-sm text-slate-700">
                <?php foreach($reports as $r): ?>
                <tr class="hover:bg-slate-50/70 transition">
                    <td class="px-6 py-4 font-medium"><?php echo htmlspecialchars($r['name_user'] . ' ' . $r['father_surname_user']); ?></td>
                    <td class="px-6 py-4 max-w-xs truncate"><?php echo htmlspecialchars($r['descripcion']); ?></td>
                    <td class="px-6 py-4">
                        <a href="<?php echo $r['foto']; ?>" target="_blank" class="text-blue-600 font-bold hover:underline text-xs">Abrir Imagen <i class="fa-solid fa-arrow-up-right-from-square ml-1"></i></a>
                    </td>
                    <td class="px-6 py-4">
                        <span class="px-2 py-1 rounded-full text-xs font-bold <?php echo $r['estado'] === 'PENDIENTE' ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'; ?>">
                            <?php echo $r['estado']; ?>
                        </span>
                    </td>
                    <td class="px-6 py-4 text-right">
                        <?php if($r['estado'] === 'PENDIENTE'): ?>
                            <a href="index.php?action=revisar_reporte&id=<?php echo $r['id']; ?>" class="bg-emerald-500 hover:bg-emerald-600 text-white font-medium text-xs px-3 py-1.5 rounded-lg transition shadow-sm">Marcar Revisado</a>
                        <?php else: ?>
                            <span class="text-slate-400 text-xs italic">Verificado</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'views/layouts/footer.php'; ?>