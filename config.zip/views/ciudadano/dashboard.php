<?php include 'views/layouts/header.php'; ?>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
    <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 h-fit">
        <h3 class="text-xl font-bold text-slate-800 mb-4"><i class="fa-solid fa-camera mr-2 text-amber-500"></i>Nuevo Reporte</h3>
        
        <form action="index.php?action=crear_reporte" method="POST" enctype="multipart/form-data" class="space-y-4">
            <div>
                <label class="block text-sm font-medium text-slate-700">Descripción del problema</label>
                <textarea name="descripcion" rows="4" required class="mt-1 block w-full rounded-xl border border-slate-300 p-3 focus:border-amber-500 focus:outline-none" placeholder="Indica el lugar exacto y el desperfecto..."></textarea>
            </div>
            <div>
                <label class="block text-sm font-medium text-slate-700">Fotografía de Evidencia</label>
                <input type="file" name="foto" accept="image/*" required class="mt-1 block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-sm file:font-semibold file:bg-amber-50 file:text-amber-700 hover:file:bg-amber-100">
            </div>
            <button type="submit" class="w-full py-3 bg-amber-500 hover:bg-amber-600 text-white font-medium rounded-xl shadow transition">Enviar Reporte a la Muni</button>
        </form>
        
        <div class="mt-6 pt-6 border-t border-slate-100">
            <a href="index.php?action=perfil" class="text-sm font-medium text-blue-600 hover:underline"><i class="fa-solid fa-user-gear mr-2"></i>Configurar cuenta / Perfil</a>
        </div>
    </div>

    <div class="lg:col-span-2 space-y-6">
        <?php if(!empty($notifications)): ?>
            <div class="bg-blue-50 border border-blue-200 p-4 rounded-2xl flex justify-between items-center" id="notif-badge">
                <div class="flex items-center space-x-3">
                    <i class="fa-solid fa-bell text-blue-600 animate-bounce"></i>
                    <p class="text-sm text-blue-800 font-medium">Tienes alertas sobre la revisión de tus reportes.</p>
                </div>
                <button onclick="marcarLeidas()" class="text-xs bg-blue-200 hover:bg-blue-300 text-blue-800 px-3 py-1 rounded-lg font-bold transition">Marcar como leídas</button>
            </div>
        <?php endif; ?>

        <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <h3 class="text-xl font-bold text-slate-800 mb-4">Mis Reportes Enviados</h3>
            
            <?php if(empty($reports)): ?>
                <p class="text-slate-500 text-sm">Aún no has registrado ningún reporte de daños.</p>
            <?php else: ?>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <?php foreach($reports as $r): ?>
                        <div class="border border-slate-100 rounded-xl p-4 hover:shadow-md transition bg-slate-50 flex flex-col justify-between">
                            <div>
                                <div class="flex justify-between items-start mb-2">
                                    <span class="text-xs text-slate-400"><?php echo $r['created_at']; ?></span>
                                    <span class="px-2.5 py-1 rounded-full text-xs font-bold <?php echo $r['estado'] === 'PENDIENTE' ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'; ?>">
                                        <?php echo $r['estado']; ?>
                                    </span>
                                </div>
                                <p class="text-sm text-slate-700 line-clamp-2 mb-4"><?php echo htmlspecialchars($r['descripcion']); ?></p>
                            </div>
                            <button onclick="openModal('<?php echo $r['foto']; ?>', `<?php echo htmlspecialchars($r['descripcion']); ?>`, '<?php echo $r['estado']; ?>')" class="w-full py-2 bg-slate-200 hover:bg-slate-300 rounded-xl text-xs font-bold text-slate-700 transition">Ver Detalles / Foto</button>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div id="reportModal" class="hidden fixed inset-0 bg-slate-900 bg-opacity-50 backdrop-blur-sm z-50 flex justify-center items-center p-4">
    <div class="bg-white rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl transform transition-all">
        <div class="p-6">
            <div class="flex justify-between items-center mb-4">
                <h4 class="font-bold text-lg text-slate-800">Detalles del Reporte</h4>
                <button onclick="closeModal()" class="text-slate-400 hover:text-slate-600 text-2xl">&times;</button>
            </div>
            <img id="modalImg" src="" alt="Evidencia" class="w-full h-48 object-cover rounded-xl mb-4">
            <p id="modalDesc" class="text-sm text-slate-600 mb-4"></p>
            <div class="flex justify-end">
                <span id="modalEstado" class="px-3 py-1 rounded-full text-xs font-bold"></span>
            </div>
        </div>
    </div>
</div>

<script>
function openModal(imgSrc, desc, estado) {
    document.getElementById('modalImg').src = imgSrc;
    document.getElementById('modalDesc').innerText = desc;
    const badge = document.getElementById('modalEstado');
    badge.innerText = estado;
    if(estado === 'PENDIENTE') {
        badge.className = "px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800";
    } else {
        badge.className = "px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800";
    }
    document.getElementById('reportModal').classList.remove('hidden');
}
function closeModal() {
    document.getElementById('reportModal').classList.add('hidden');
}
</script>

<?php include 'views/layouts/footer.php'; ?>