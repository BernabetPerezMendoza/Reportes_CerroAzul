<?php include 'views/layouts/header.php'; ?>
<div class="max-w-2xl mx-auto bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
    <div class="p-6 border-b border-slate-100 bg-slate-50">
        <h3 class="font-black text-xl text-slate-800">Mi Perfil Ciudadano</h3>
        <p class="text-xs text-slate-500 mt-1">Los datos oficiales de identidad no son editables por seguridad.</p>
    </div>
    <div class="p-6 space-y-4">
        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="text-xs font-bold uppercase tracking-wider text-slate-400">Nombres completos</label>
                <p class="mt-1 font-medium text-slate-800 bg-slate-100 p-2.5 rounded-xl"><?php echo htmlspecialchars($userData['name_user']); ?></p>
            </div>
            <div>
                <label class="text-xs font-bold uppercase tracking-wider text-slate-400">Apellidos</label>
                <p class="mt-1 font-medium text-slate-800 bg-slate-100 p-2.5 rounded-xl"><?php echo htmlspecialchars($userData['father_surname_user'] . ' ' . $userData['mother_surname_user']); ?></p>
            </div>
        </div>
        <div>
            <label class="text-xs font-bold uppercase tracking-wider text-slate-400">Número de Documento (DNI)</label>
            <p class="mt-1 font-medium text-slate-800 bg-slate-100 p-2.5 rounded-xl"><?php echo htmlspecialchars($userData['dni_user']); ?></p>
        </div>

        <hr class="border-slate-100 my-6">

        <form action="index.php?action=perfil" method="POST" class="space-y-4">
            <div>
                <label class="block text-sm font-medium text-slate-700">Cambiar Nombre de Usuario</label>
                <input type="text" name="username_user" value="<?php echo htmlspecialchars($userData['username_user']); ?>" required class="mt-1 block w-full rounded-xl border border-slate-300 p-3 shadow-sm focus:border-amber-500 focus:outline-none">
            </div>
            <button type="submit" class="bg-amber-500 hover:bg-amber-600 text-white text-sm font-medium px-4 py-2 rounded-xl transition">Guardar Cambios de Inicio de Sesión</button>
        </form>
    </div>
</div>
<?php include 'views/layouts/footer.php'; ?>