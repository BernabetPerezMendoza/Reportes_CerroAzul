<?php include 'views/layouts/header.php'; ?>
<div class="min-h-[80vh] flex flex-col justify-center py-12 sm:px-6 lg:px-8">
    <div class="sm:mx-auto w-full max-w-md">
        <div class="bg-white py-8 px-4 shadow-xl rounded-2xl sm:px-10 border border-slate-100">
            <h2 class="text-center text-3xl font-extrabold text-slate-900 mb-6">Registro de Ciudadano</h2>
            
            <?php if(isset($error)): ?>
                <div class="bg-red-50 text-red-600 p-3 rounded-xl text-sm mb-4 border border-red-200"><?php echo $error; ?></div>
            <?php endif; ?>

            <form action="index.php?action=register" method="POST" class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-slate-700">Número de DNI</label>
                    <input type="text" name="dni" maxlength="8" minlength="8" required class="mt-1 block w-full rounded-xl border border-slate-300 px-3 py-2 shadow-sm focus:border-amber-500 focus:outline-none" placeholder="Validación automática con RENIEC">
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700">Nombre de Usuario (Para iniciar sesión)</label>
                    <input type="text" name="username" required class="mt-1 block w-full rounded-xl border border-slate-300 px-3 py-2 shadow-sm focus:border-amber-500 focus:outline-none">
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700">Contraseña</label>
                    <input type="password" name="password" required class="mt-1 block w-full rounded-xl border border-slate-300 px-3 py-2 shadow-sm focus:border-amber-500 focus:outline-none">
                </div>
                <button type="submit" class="w-full py-3 px-4 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-xl shadow transition">Validar y Registrar</button>
            </form>
            <p class="mt-4 text-center text-sm text-slate-600"><a href="index.php?action=login" class="text-slate-600 font-medium hover:underline">Regresar al login</a></p>
        </div>
    </div>
</div>
<?php include 'views/layouts/footer.php'; ?>