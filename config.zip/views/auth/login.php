<?php include 'views/layouts/header.php'; ?>
<div class="min-h-[80vh] flex flex-col justify-center py-12 sm:px-6 lg:px-8">
    <div class="sm:mx-auto w-full max-w-md">
        <div class="bg-white py-8 px-4 shadow-xl rounded-2xl sm:px-10 border border-slate-100">
            <h2 class="text-center text-3xl font-extrabold text-slate-900 mb-6">Iniciar Sesión</h2>
            
            <?php if(isset($error)): ?>
                <div class="bg-red-50 text-red-600 p-3 rounded-xl text-sm mb-4 border border-red-200"><?php echo $error; ?></div>
            <?php endif; ?>
            <?php if(isset($_GET['success'])): ?>
                <div class="bg-emerald-50 text-emerald-600 p-3 rounded-xl text-sm mb-4 border border-emerald-200">¡Registro exitoso! Ya puedes ingresar.</div>
            <?php endif; ?>

            <form action="index.php?action=login" method="POST" class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-slate-700">Usuario</label>
                    <input type="text" name="username" required class="mt-1 block w-full rounded-xl border border-slate-300 px-3 py-2 shadow-sm focus:border-amber-500 focus:outline-none focus:ring-amber-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700">Contraseña</label>
                    <input type="password" name="password" required class="mt-1 block w-full rounded-xl border border-slate-300 px-3 py-2 shadow-sm focus:border-amber-500 focus:outline-none focus:ring-amber-500">
                </div>
                <button type="submit" class="w-full py-3 px-4 bg-amber-500 hover:bg-amber-600 text-white font-medium rounded-xl shadow transition">Ingresar</button>
            </form>
            <p class="mt-4 text-center text-sm text-slate-600">¿No tienes cuenta? <a href="index.php?action=register" class="text-amber-600 font-medium hover:underline">Regístrate con tu DNI</a></p>
        </div>
    </div>
</div>
<?php include 'views/layouts/footer.php'; ?>