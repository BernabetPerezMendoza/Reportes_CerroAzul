<?php
if (session_status() === PHP_SESSION_NONE) session_start();

// Carga de Controladores de forma automatizada
require_once 'controllers/AuthController.php';
require_once 'controllers/ReportController.php';
require_once 'controllers/AdminController.php';

$action = $_GET['action'] ?? 'login';

// Rutas Públicas de Acceso Libre
$publicActions = ['login', 'register'];

if (!isset($_SESSION['user_id']) && !in_array($action, $publicActions)) {
    header("Location: index.php?action=login");
    exit();
}

switch ($action) {
    case 'login':
        $controller = new AuthController();
        $controller->login();
        break;
    case 'register':
        $controller = new AuthController();
        $controller->register();
        break;
    case 'logout':
        $controller = new AuthController();
        $controller->logout();
        break;
    case 'ciudadano_dashboard':
        $controller = new ReportController();
        $controller->ciudadanoDashboard();
        break;
    case 'crear_reporte':
        $controller = new ReportController();
        $controller->crearReporte();
        break;
    case 'perfil':
        $controller = new ReportController();
        $controller->perfil();
        break;
    case 'marcar_leidas':
        $controller = new ReportController();
        $controller->marcarNotificacionesLeidas();
        break;
    case 'admin_dashboard':
        $controller = new AdminController();
        $controller->dashboard();
        break;
    case 'revisar_reporte':
        $controller = new AdminController();
        $controller->revisarReporte();
        break;
    case 'admin_usuarios':
        $controller = new AdminController();
        $controller->usuarios();
        break;
    default:
        echo "404 - Página no encontrada.";
        break;
}