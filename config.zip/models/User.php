<?php

class User {
    private $conn;
    private $table_name = "users";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function getByUsername($username) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE username_user = :username LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function getByDni($dni) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE dni_user = :dni LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':dni', $dni);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function consultarAPI_DNI($dni) {
        $token = "ae69a4dddfa40925303652b461c09b8922437252ccd277a83ebe1c1d10b4d9c3";
        $params = json_encode(['dni' => $dni]);
        
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://apiperu.dev/api/dni",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_POSTFIELDS => $params,        
            CURLOPT_HTTPHEADER => [
                'Accept: application/json',
                'Content-Type: application/json',
                'Authorization: Bearer ' . $token
            ],        
        ));
        
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);

        if ($err) return false;
        
        $data = json_decode($response, true);
        if(isset($data['success']) && $data['success'] == true) {
            return $data['data'];
        }
        return false;
    }

    public function register($dni, $name, $father_surname, $mother_surname, $username, $password, $rol = 2) {
        $query = "INSERT INTO " . $this->table_name . " 
                  (dni_user, name_user, father_surname_user, mother_surname_user, username_user, password_user, rol_user) 
                  VALUES (:dni, :name, :father, :mother, :username, :password, :rol)";
        
        $stmt = $this->conn->prepare($query);
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);

        $stmt->bindParam(':dni', $dni);
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':father', $father_surname);
        $stmt->bindParam(':mother', $mother_surname);
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':password', $hashed_password);
        $stmt->bindParam(':rol', $rol);

        return $stmt->execute();
    }

    public function updateUsername($id_user, $new_username) {
        $query = "UPDATE " . $this->table_name . " SET username_user = :username WHERE id_user = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':username', $new_username);
        $stmt->bindParam(':id', $id_user);
        return $stmt->execute();
    }

    public function getAll() {
        $query = "SELECT id_user, dni_user, name_user, father_surname_user, mother_surname_user, username_user, rol_user, created_at 
                  FROM " . $this->table_name . " ORDER BY id_user DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}