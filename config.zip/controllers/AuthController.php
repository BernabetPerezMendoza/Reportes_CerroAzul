<?php

require_once 'config/Database.php';
require_once 'models/User.php';

class AuthController {
    private $db;
    private $userModel;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->userModel = new User($this->db);
    }

    public function login() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            $username = trim($_POST['username']);
            $password = trim($_POST['password']);

            $user = $this->userModel->getByUsername($username);

            if ($user && password_verify($password, trim($user['password_user']))) {
                if (session_status() === PHP_SESSION_NONE) session_start();
                $_SESSION['user_id'] = $user['id_user'];
                $_SESSION['username'] = $user['username_user'];
                $_SESSION['role'] = $user['rol_user'];
                $_SESSION['full_name'] = $user['name_user'] . ' ' . $user['father_surname_user'];

                if ($_SESSION['role'] == 1) {
                    header("Location: index.php?action=admin_dashboard");
                } else {
                    header("Location: index.php?action=ciudadano_dashboard");
                }
                exit();
            } else {
                $error = "Usuario o contraseña incorrectos.";
                require_once 'views/auth/login.php';
            }
        } else {
            require_once 'views/auth/login.php';
        }
    }

    public function register() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $dni = trim($_POST['dni']);
            $username = trim($_POST['username']);
            $password = trim($_POST['password']);

            if(strlen($dni) !== 8) {
                $error = "El DNI debe tener 8 dígitos.";
                return require_once 'views/auth/register.php';
            }

            // Validar si usuario o DNI ya existen localmente
            if($this->userModel->getByDni($dni) || $this->userModel->getByUsername($username)) {
                $error = "El DNI o el Nombre de usuario ya se encuentran registrados.";
                return require_once 'views/auth/register.php';
            }

            // Consultar a la API de Perú
            $apiData = $this->userModel->consultarAPI_DNI($dni);
            if(!$apiData) {
                $error = "No se pudo validar el DNI con el Registro Nacional. Verifique el número.";
                return require_once 'views/auth/register.php';
            }

            // Registro exitoso usando datos de la API
            $registerSuccess = $this->userModel->register(
                $dni,
                $apiData['nombres'],
                $apiData['apellido_paterno'],
                $apiData['apellido_materno'],
                $username,
                $password
            );

            if($registerSuccess) {
                header("Location: index.php?action=login&success=1");
                exit();
            } else {
                $error = "Ocurrió un error al procesar el registro.";
                require_once 'views/auth/register.php';
            }
        } else {
            require_once 'views/auth/register.php';
        }
    }

    public function logout() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        session_destroy();
        header("Location: index.php?action=login");
        exit();
    }
}