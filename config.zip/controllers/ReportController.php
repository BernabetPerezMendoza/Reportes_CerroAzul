<?php

require_once 'config/Database.php';
require_once 'models/Report.php';
require_once 'models/Notification.php';
require_once 'models/User.php';

class ReportController {
    private $db;
    private $reportModel;
    private $notificationModel;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->reportModel = new Report($this->db);
        $this->notificationModel = new Notification($this->db);
        
        if (session_status() === PHP_SESSION_NONE) session_start();
        if(!isset($_SESSION['user_id'])) {
            header("Location: index.php?action=login");
            exit();
        }
    }

    public function ciudadanoDashboard() {
        $reports = $this->reportModel->getByUserId($_SESSION['user_id']);
        $notifications = $this->notificationModel->getUnreadByUserId($_SESSION['user_id']);
        require_once 'views/ciudadano/dashboard.php';
    }

    public function crearReporte() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $descripcion = trim($_POST['descripcion']);
            
            // Subida de archivos
            $target_dir = "uploads/";
            if (!file_exists($target_dir)) {
                mkdir($target_dir, 0777, true);
            }
            
            $file_extension = pathinfo($_FILES["foto"]["name"], PATHINFO_EXTENSION);
            $new_file_name = uniqid() . '.' . $file_extension;
            $target_file = $target_dir . $new_file_name;

            if (move_uploaded_file($_FILES["foto"]["tmp_name"], $target_file)) {
                $this->reportModel->create($_SESSION['user_id'], $descripcion, $target_file);
                
                // Notificar a los administradores (Enviamos notificación al admin por defecto ID: 1)
                $this->notificationModel->create(1, "El ciudadano " . $_SESSION['full_name'] . " ha enviado un nuevo reporte.");
                
                header("Location: index.php?action=ciudadano_dashboard&report_success=1");
                exit();
            }
        }
    }

    public function perfil() {
        $userModel = new User($this->db);
        $userData = $userModel->getByUsername($_SESSION['username']);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $new_username = trim($_POST['username_user']);
            if(!empty($new_username)) {
                $userModel->updateUsername($_SESSION['user_id'], $new_username);
                $_SESSION['username'] = $new_username;
                header("Location: index.php?action=perfil&success=1");
                exit();
            }
        }
        require_once 'views/ciudadano/perfil.php';
    }
    
    public function marcarNotificacionesLeidas() {
        $this->notificationModel->markAsRead($_SESSION['user_id']);
        echo json_encode(['status' => 'success']);
    }
}