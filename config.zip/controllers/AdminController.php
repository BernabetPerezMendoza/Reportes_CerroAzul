<?php

require_once 'config/Database.php';
require_once 'models/Report.php';
require_once 'models/Notification.php';
require_once 'models/User.php';

class AdminController {
    private $db;
    private $reportModel;
    private $notificationModel;
    private $userModel;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->reportModel = new Report($this->db);
        $this->notificationModel = new Notification($this->db);
        $this->userModel = new User($this->db);

        if (session_status() === PHP_SESSION_NONE) session_start();
        if(!isset($_SESSION['user_id']) || $_SESSION['role'] != 1) {
            header("Location: index.php?action=login");
            exit();
        }
    }

    public function dashboard() {
        $counts = $this->reportModel->getCounts();
        $reports = $this->reportModel->getAllWithUser();
        $notifications = $this->notificationModel->getUnreadByUserId($_SESSION['user_id']);
        require_once 'views/admin/dashboard.php';
    }

    public function revisarReporte() {
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $report = $this->reportModel->getById($id);
            
            if($report) {
                $this->reportModel->updateStatus($id, 'REVISADO');
                // Alerta al ciudadano dueño del reporte
                $this->notificationModel->create($report['user_id'], "Tu reporte ID #$id ha sido revisado por la Municipalidad.");
            }
            header("Location: index.php?action=admin_dashboard&status_updated=1");
            exit();
        }
    }

    public function usuarios() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $dni = trim($_POST['dni']);
            $username = trim($_POST['username']);
            $password = trim($_POST['password']);
            $rol = intval($_POST['rol_user']);

            $apiData = $this->userModel->consultarAPI_DNI($dni);
            if($apiData) {
                $this->userModel->register($dni, $apiData['nombres'], $apiData['apellido_paterno'], $apiData['apellido_materno'], $username, $password, $rol);
                header("Location: index.php?action=admin_usuarios&success=1");
                exit();
            } else {
                $error = "No se pudo validar el DNI.";
            }
        }
        $users = $this->userModel->getAll();
        require_once 'views/admin/usuarios.php';
    }
}