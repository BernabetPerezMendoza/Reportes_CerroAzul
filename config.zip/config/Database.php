<?php

class Database {
    private $host;
    private $db_name;
    private $username;
    private $password;
    public $conn;

    public function getConnection() {
        // Usamos SERVER_NAME o validamos si contiene 'localhost' o '127.0.0.1'
        if ($_SERVER['SERVER_NAME'] == 'localhost' || $_SERVER['REMOTE_ADDR'] == '127.0.0.1' || strpos($_SERVER['HTTP_HOST'], 'localhost') !== false) {
            
            $this->host = "localhost";
            $this->db_name = "reportes_cerroazul";
            $this->username = "root";
            $this->password = ""; 
        } else {
            
            // Aquí irán los datos reales de tu Hosting cuando lo subas
            $this->host = "sql207.ezyro.com";
            $this->db_name = "ezyro_42273482_reportes_cerroazul";
            $this->username = "ezyro_42273482";
            $this->password = "b5732b352afd";
        }

        $this->conn = null;

        try {
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
            $this->conn->exec("set names utf8");
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $exception) {
            echo "Error de conexión: " . $exception->getMessage();
        }

        return $this->conn;
    }
}